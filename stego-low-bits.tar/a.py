from PIL import Image
import os

im = Image.open("tiger.jpg")
marca = Image.open("marca.jpg")

pixels = im.load()
width, height = im.size

marcapixels = marca.load()

msb = Image.new("L", (width, height))
msbpixels = msb.load()

for x in range(width):
    for y in range(height):
        cpixel = pixels[x, y]
    mpixel = marcapixels[x, y]
    a = (mpixel & 224) >> 5
    msbpixels[x,y] = (cpixel & 248) + a

msb.save("tigerwithmark.jpg", "JPEG", quality=100)